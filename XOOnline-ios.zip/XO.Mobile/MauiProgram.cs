using Microsoft.Extensions.Logging;
using XO.Mobile.Pages;
using XO.Mobile.Services;

namespace XO.Mobile;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder.UseMauiApp<App>();

        builder.Services.AddSingleton<ApiClient>();
        builder.Services.AddSingleton<GameClient>();
        builder.Services.AddSingleton<AppShell>();

        builder.Services.AddTransient<RegisterPage>();
        builder.Services.AddTransient<LobbyPage>();
        builder.Services.AddTransient<LeaderboardPage>();
        builder.Services.AddTransient<ProfilePage>();
        builder.Services.AddTransient<GamePage>();

#if DEBUG
        builder.Logging.AddDebug();
#endif
        return builder.Build();
    }
}
