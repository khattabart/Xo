using XO.Shared;

namespace XO.Mobile.Services;

/// <summary>ألوان تُستخدم من الكود (الخلايا واللوحة) وتتبع الوضع الفاتح/الداكن.</summary>
public static class Theme
{
    private static bool Dark => Application.Current?.RequestedTheme == AppTheme.Dark;

    public static Color X => Dark ? Color.FromArgb("#FF7B5E") : Color.FromArgb("#C8432B");
    public static Color O => Dark ? Color.FromArgb("#5ECFC9") : Color.FromArgb("#1D6E75");
    public static Color Surface => Dark ? Color.FromArgb("#172220") : Color.FromArgb("#F7F8F5");
    public static Color Bg => Dark ? Color.FromArgb("#0F1614") : Color.FromArgb("#ECEFEA");
    public static Color Line => Dark ? Color.FromArgb("#2A3835") : Color.FromArgb("#CBD3CE");
    public static Color Ink => Dark ? Color.FromArgb("#E8EEEA") : Color.FromArgb("#17221F");
    public static Color Muted => Dark ? Color.FromArgb("#9AAAA4") : Color.FromArgb("#4D5B57");

    public static Color TierColor(int rating) => Color.FromArgb(Rankings.TierOf(rating).Color);
}

/// <summary>صف لوحة الترتيب (يضيف خصائص عرض فوق الـ DTO).</summary>
public class LeaderboardRow
{
    public LeaderboardRow(LeaderboardEntry e, Guid me)
    {
        Rank = e.Rank.ToString();
        Nickname = e.Nickname + (e.PlayerId == me ? " (أنت)" : "");
        Rating = e.Rating.ToString();
        Tier = Rankings.TierOf(e.Rating).Name;
        TierColor = Theme.TierColor(e.Rating);
        Level = $"مستوى {e.Level}";
        Record = $"{e.Wins} فوز · {e.Draws} تعادل · {e.Losses} خسارة";
        OnlineColor = e.Online ? Color.FromArgb("#2E7D4F") : Theme.Line;
        IsMe = e.PlayerId == me;
    }

    public string Rank { get; }
    public string Nickname { get; }
    public string Rating { get; }
    public string Tier { get; }
    public Color TierColor { get; }
    public string Level { get; }
    public string Record { get; }
    public Color OnlineColor { get; }
    public bool IsMe { get; }
}
