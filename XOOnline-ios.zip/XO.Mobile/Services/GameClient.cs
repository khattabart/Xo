using Microsoft.AspNetCore.SignalR.Client;
using XO.Shared;

namespace XO.Mobile.Services;

/// <summary>اتصال SignalR بالسيرفر. الأحداث تصل من خيط خلفي، فالصفحات تحوّلها إلى خيط الواجهة.</summary>
public class GameClient
{
    private readonly ApiClient _api;
    private HubConnection? _conn;

    public GameClient(ApiClient api) => _api = api;

    public GameState? Current { get; private set; }
    public int Online { get; private set; }
    public bool IsConnected => _conn?.State == HubConnectionState.Connected;

    public event Action<GameState>? GameUpdated;
    public event Action? LobbyChanged;
    public event Action<int>? OnlineChanged;
    public event Action<bool>? ConnectionChanged;

    public async Task<string?> ConnectAsync()
    {
        if (IsConnected) return null;
        try
        {
            if (_conn is not null) await _conn.DisposeAsync();

            _conn = new HubConnectionBuilder()
                .WithUrl($"{_api.ServerUrl}/hub", o =>
                {
                    o.AccessTokenProvider = () => Task.FromResult<string?>(_api.HubToken);
                })
                .WithAutomaticReconnect()
                .Build();

            _conn.On<GameState>("GameUpdated", s =>
            {
                Current = s;
                GameUpdated?.Invoke(s);
            });
            _conn.On("LobbyChanged", () => LobbyChanged?.Invoke());
            _conn.On<int>("OnlineCount", n =>
            {
                Online = n;
                OnlineChanged?.Invoke(n);
            });
            _conn.Reconnected += _ => { ConnectionChanged?.Invoke(true); return Task.CompletedTask; };
            _conn.Reconnecting += _ => { ConnectionChanged?.Invoke(false); return Task.CompletedTask; };
            _conn.Closed += _ => { ConnectionChanged?.Invoke(false); return Task.CompletedTask; };

            await _conn.StartAsync();
            ConnectionChanged?.Invoke(true);
            return null;
        }
        catch
        {
            return "تعذّر الاتصال بالسيرفر. تأكد من تشغيله ومن عنوانه في صفحة حسابي.";
        }
    }

    public async Task DisconnectAsync()
    {
        if (_conn is null) return;
        try { await _conn.StopAsync(); } catch { }
    }

    /// <summary>يمسح المباراة المنتهية من الذاكرة بعد أن يغادر اللاعب شاشتها.</summary>
    public void ClearIfDone()
    {
        if (Current is { IsDone: true }) Current = null;
    }

    private async Task<MatchResult> Call(string method, params object[] args)
    {
        if (!IsConnected && await ConnectAsync() is { } err) return MatchResult.Fail(err);
        try
        {
            var r = args.Length switch
            {
                0 => await _conn!.InvokeAsync<MatchResult>(method),
                1 => await _conn!.InvokeAsync<MatchResult>(method, args[0]),
                _ => await _conn!.InvokeAsync<MatchResult>(method, args[0], args[1]),
            };
            if (r.Ok && r.Game is not null) Current = r.Game;
            return r;
        }
        catch
        {
            return MatchResult.Fail("انقطع الاتصال بالسيرفر. جرّب مرة ثانية.");
        }
    }

    public Task<MatchResult> QuickMatch() => Call("QuickMatch");
    public Task<MatchResult> CreateGame() => Call("CreateGame");
    public Task<MatchResult> JoinGame(Guid id) => Call("JoinGame", id);
    public Task<MatchResult> MakeMove(Guid id, int index) => Call("MakeMove", id, index);
    public Task<MatchResult> Resign(Guid id) => Call("Resign", id);
    public Task<MatchResult> ClaimTimeout(Guid id) => Call("ClaimTimeout", id);
    public Task<MatchResult> CancelGame(Guid id) => Call("CancelGame", id);

    public async Task<List<OpenGame>> GetOpenGames()
    {
        if (!IsConnected && await ConnectAsync() is not null) return new();
        try { return await _conn!.InvokeAsync<List<OpenGame>>("GetOpenGames"); }
        catch { return new(); }
    }
}
