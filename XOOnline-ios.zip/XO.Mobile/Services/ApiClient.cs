using System.Net.Http.Headers;
using System.Net.Http.Json;
using Microsoft.Maui.Storage;
using XO.Shared;

namespace XO.Mobile.Services;

/// <summary>التسجيل وجلب الملف الشخصي ولوحة الترتيب عبر HTTP، وحفظ بيانات الدخول على الجهاز.</summary>
public class ApiClient
{
    /// <summary>عنوان السيرفر الافتراضي للمحاكي: 10.0.2.2 هو جهاز الكمبيوتر من داخل محاكي أندرويد.</summary>
    public const string DefaultServerUrl = "http://10.0.2.2:5050";

    private readonly HttpClient _http = new() { Timeout = TimeSpan.FromSeconds(15) };

    public string ServerUrl
    {
        get => Preferences.Get("server_url", DefaultServerUrl);
        set => Preferences.Set("server_url", value.Trim().TrimEnd('/'));
    }

    public Guid PlayerId { get; private set; }
    public string Token { get; private set; } = "";
    public string Nickname { get; private set; } = "";

    public bool IsRegistered => PlayerId != Guid.Empty && Token.Length > 0;
    public string HubToken => $"{PlayerId}.{Token}";

    public async Task LoadAsync()
    {
        try
        {
            var id = await SecureStorage.Default.GetAsync("player_id");
            var token = await SecureStorage.Default.GetAsync("player_token");
            if (Guid.TryParse(id, out var g) && !string.IsNullOrEmpty(token))
            {
                PlayerId = g;
                Token = token;
                Nickname = Preferences.Get("nickname", "");
            }
        }
        catch
        {
            // التخزين الآمن قد يفشل بعد مسح بيانات التطبيق؛ نعتبر اللاعب غير مسجّل.
        }
    }

    /// <summary>يرجع null عند النجاح، أو رسالة الخطأ.</summary>
    public async Task<string?> RegisterAsync(string nickname)
    {
        try
        {
            var res = await _http.PostAsJsonAsync($"{ServerUrl}/api/register", new RegisterRequest { Nickname = nickname });
            if (!res.IsSuccessStatusCode) return await ReadError(res);

            var body = await res.Content.ReadFromJsonAsync<RegisterResponse>();
            if (body is null) return "استجابة غير متوقعة من السيرفر.";

            PlayerId = body.PlayerId;
            Token = body.Token;
            Nickname = body.Nickname;
            await SecureStorage.Default.SetAsync("player_id", PlayerId.ToString());
            await SecureStorage.Default.SetAsync("player_token", Token);
            Preferences.Set("nickname", Nickname);
            return null;
        }
        catch
        {
            return "تعذّر الاتصال بالسيرفر. تأكد من تشغيله ومن عنوانه في صفحة حسابي.";
        }
    }

    public void Logout()
    {
        try { SecureStorage.Default.Remove("player_id"); SecureStorage.Default.Remove("player_token"); } catch { }
        Preferences.Remove("nickname");
        PlayerId = Guid.Empty;
        Token = "";
        Nickname = "";
    }

    public async Task<PlayerProfile?> GetMeAsync()
    {
        try
        {
            using var req = Authed(HttpMethod.Get, "/api/me");
            using var res = await _http.SendAsync(req);
            if (!res.IsSuccessStatusCode) return null;
            var me = await res.Content.ReadFromJsonAsync<PlayerProfile>();
            if (me is not null) { Nickname = me.Nickname; Preferences.Set("nickname", Nickname); }
            return me;
        }
        catch { return null; }
    }

    public async Task<List<LeaderboardEntry>> GetLeaderboardAsync(int take = 50)
    {
        try
        {
            return await _http.GetFromJsonAsync<List<LeaderboardEntry>>($"{ServerUrl}/api/leaderboard?take={take}")
                   ?? new();
        }
        catch { return new(); }
    }

    public async Task<string?> RenameAsync(string nickname)
    {
        try
        {
            using var req = Authed(HttpMethod.Put, "/api/me/nickname");
            req.Content = JsonContent.Create(new RenameRequest { Nickname = nickname });
            using var res = await _http.SendAsync(req);
            if (!res.IsSuccessStatusCode) return await ReadError(res);
            Nickname = nickname.Trim();
            Preferences.Set("nickname", Nickname);
            return null;
        }
        catch { return "تعذّر الاتصال بالسيرفر."; }
    }

    private HttpRequestMessage Authed(HttpMethod method, string path)
    {
        var req = new HttpRequestMessage(method, ServerUrl + path);
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", HubToken);
        return req;
    }

    private static async Task<string> ReadError(HttpResponseMessage res)
    {
        try
        {
            var err = await res.Content.ReadFromJsonAsync<ErrorResponse>();
            if (!string.IsNullOrWhiteSpace(err?.Error)) return err!.Error;
        }
        catch { }
        return $"خطأ من السيرفر ({(int)res.StatusCode}).";
    }
}
