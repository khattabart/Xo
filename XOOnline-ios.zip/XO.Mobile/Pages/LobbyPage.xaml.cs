using XO.Mobile.Services;
using XO.Shared;

namespace XO.Mobile.Pages;

public partial class LobbyPage : ContentPage
{
    private readonly ApiClient _api;
    private readonly GameClient _game;
    private bool _busy;

    public LobbyPage(ApiClient api, GameClient game)
    {
        InitializeComponent();
        _api = api;
        _game = game;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        _game.LobbyChanged -= OnLobbyChanged; _game.LobbyChanged += OnLobbyChanged;
        _game.OnlineChanged -= OnOnlineChanged; _game.OnlineChanged += OnOnlineChanged;
        _game.GameUpdated -= OnGameUpdated; _game.GameUpdated += OnGameUpdated;

        if (!_api.IsRegistered) await _api.LoadAsync();
        await LoadAll();
    }

    protected override void OnDisappearing()
    {
        base.OnDisappearing();
        _game.LobbyChanged -= OnLobbyChanged;
        _game.OnlineChanged -= OnOnlineChanged;
        _game.GameUpdated -= OnGameUpdated;
    }

    // ---------- تحميل البيانات ----------

    private async Task LoadAll()
    {
        var error = await _game.ConnectAsync();
        if (error is not null)
        {
            ShowStatus(error);
            return;
        }
        ShowStatus(null);

        var me = await _api.GetMeAsync();
        if (me is not null)
        {
            NameLabel.Text = me.Nickname;
            var tier = Rankings.TierOf(me.Rating);
            TierLabel.Text = tier.Name;
            TierLabel.TextColor = Theme.TierColor(me.Rating);
            LevelLabel.Text = $"مستوى {me.Level}";
            RatingLabel.Text = $"تصنيف {me.Rating}";
        }
        OnlineLabel.Text = $"{_game.Online} متصل الآن";
        await RefreshOpenGames();
        UpdateBanner();
    }

    private async Task RefreshOpenGames()
    {
        OpenList.ItemsSource = await _game.GetOpenGames();
    }

    private void UpdateBanner()
    {
        var g = _game.Current;
        var active = g is { IsDone: false };
        ActiveBanner.IsVisible = active;
        if (!active || g is null) return;

        if (g.IsWaiting)
            ActiveLabel.Text = "مباراتك مفتوحة وبانتظار خصم";
        else
        {
            var opponent = g.XId == _api.PlayerId ? g.OName : g.XName;
            ActiveLabel.Text = $"عندك مباراة جارية ضد {opponent}";
        }
    }

    private void ShowStatus(string? message)
    {
        StatusLabel.Text = message ?? "";
        StatusLabel.IsVisible = !string.IsNullOrEmpty(message);
    }

    // ---------- أحداث السيرفر ----------

    private void OnLobbyChanged() => MainThread.BeginInvokeOnMainThread(async () => await RefreshOpenGames());

    private void OnOnlineChanged(int n) =>
        MainThread.BeginInvokeOnMainThread(() => OnlineLabel.Text = $"{n} متصل الآن");

    private void OnGameUpdated(GameState s) => MainThread.BeginInvokeOnMainThread(UpdateBanner);

    // ---------- الأزرار ----------

    private async void OnRefreshing(object? sender, EventArgs e)
    {
        await LoadAll();
        Refresher.IsRefreshing = false;
    }

    private async void OnQuick(object? sender, EventArgs e) => await Start(() => _game.QuickMatch());
    private async void OnCreate(object? sender, EventArgs e) => await Start(() => _game.CreateGame());

    private async void OnJoin(object? sender, EventArgs e)
    {
        if (sender is Button { BindingContext: OpenGame og })
            await Start(() => _game.JoinGame(og.Id));
    }

    private async void OnResume(object? sender, EventArgs e) =>
        await Shell.Current.GoToAsync(nameof(GamePage));

    private async void OnPractice(object? sender, EventArgs e) =>
        await Shell.Current.GoToAsync($"{nameof(GamePage)}?mode=practice");

    private async Task Start(Func<Task<MatchResult>> action)
    {
        if (_busy) return;
        _busy = true;
        try
        {
            ShowStatus(null);
            var result = await action();
            if (!result.Ok)
            {
                ShowStatus(result.Error);
                await RefreshOpenGames();
                return;
            }
            await Shell.Current.GoToAsync(nameof(GamePage));
        }
        finally
        {
            _busy = false;
        }
    }
}
