using XO.Mobile.Services;
using XO.Shared;

namespace XO.Mobile.Pages;

public partial class ProfilePage : ContentPage
{
    private readonly ApiClient _api;
    private readonly GameClient _game;

    public ProfilePage(ApiClient api, GameClient game)
    {
        InitializeComponent();
        _api = api;
        _game = game;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        ServerEntry.Text = _api.ServerUrl;
        await Load();
    }

    private async Task Load()
    {
        var me = await _api.GetMeAsync();
        if (me is null)
        {
            ShowMessage("تعذّر جلب بياناتك. تأكد من الاتصال بالسيرفر.");
            return;
        }

        NameLabel.Text = me.Nickname;
        NickEntry.Text = me.Nickname;

        var tier = Rankings.TierOf(me.Rating);
        TierLabel.Text = tier.Name;
        TierLabel.TextColor = Theme.TierColor(me.Rating);
        RatingLabel.Text = $"تصنيف {me.Rating}";

        var level = me.Level;
        var (lo, hi) = Rankings.LevelRange(level);
        LevelLabel.Text = $"المستوى {level}";
        XpLabel.Text = $"{me.Xp} / {hi} نقطة خبرة";
        XpBar.ProgressColor = Theme.O;
        await XpBar.ProgressTo((double)(me.Xp - lo) / (hi - lo), 300, Easing.CubicOut);

        GamesLabel.Text = me.Games.ToString();
        WinsLabel.Text = me.Wins.ToString();
        DrawsLabel.Text = me.Draws.ToString();
        LossesLabel.Text = me.Losses.ToString();

        Ladder.Children.Clear();
        foreach (var t in Rankings.Tiers)
        {
            var current = t.Name == tier.Name;
            Ladder.Children.Add(new Label
            {
                Text = $"{t.Name} {t.Min}+",
                TextColor = Color.FromArgb(t.Color),
                FontAttributes = current ? FontAttributes.Bold : FontAttributes.None,
                FontSize = current ? 15 : 13,
                Margin = new Thickness(0, 0, 14, 4),
            });
        }
    }

    private async void OnRename(object? sender, EventArgs e)
    {
        var error = await _api.RenameAsync(NickEntry.Text ?? "");
        ShowMessage(error ?? "تم حفظ الاسم.");
        if (error is null) await Load();
    }

    private async void OnSaveServer(object? sender, EventArgs e)
    {
        var url = (ServerEntry.Text ?? "").Trim();
        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri) || (uri.Scheme != "http" && uri.Scheme != "https"))
        {
            ShowMessage("عنوان السيرفر غير صحيح. مثال: http://192.168.1.10:5050");
            return;
        }
        _api.ServerUrl = url;
        await _game.DisconnectAsync();
        var error = await _game.ConnectAsync();
        ShowMessage(error ?? "تم الاتصال بالسيرفر.");
    }

    private async void OnLogout(object? sender, EventArgs e)
    {
        await _game.DisconnectAsync();
        _api.Logout();
        await Shell.Current.GoToAsync("//register");
    }

    private void ShowMessage(string text)
    {
        MessageLabel.Text = text;
        MessageLabel.IsVisible = true;
    }
}
