using XO.Mobile.Services;

namespace XO.Mobile.Pages;

public partial class LeaderboardPage : ContentPage
{
    private readonly ApiClient _api;

    public LeaderboardPage(ApiClient api)
    {
        InitializeComponent();
        _api = api;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await Load();
    }

    private async Task Load()
    {
        var entries = await _api.GetLeaderboardAsync(50);
        BoardList.ItemsSource = entries.Select(e => new LeaderboardRow(e, _api.PlayerId)).ToList();
    }

    private async void OnRefreshing(object? sender, EventArgs e)
    {
        await Load();
        Refresher.IsRefreshing = false;
    }
}
