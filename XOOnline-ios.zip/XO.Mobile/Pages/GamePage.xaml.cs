using XO.Mobile.Services;
using XO.Shared;

namespace XO.Mobile.Pages;

[QueryProperty(nameof(Mode), "mode")]
public partial class GamePage : ContentPage
{
    private static readonly TimeSpan ClaimAfter = TimeSpan.FromSeconds(45);

    private readonly ApiClient _api;
    private readonly GameClient _game;
    private readonly Button[] _cells = new Button[9];

    private GameState? _state;
    private DateTime _receivedAt = DateTime.UtcNow;
    private Match? _practice;
    private string _myMark = "";
    private bool _confirming;
    private bool _busy;
    private bool _started;
    private IDispatcherTimer? _timer;

    public string Mode { get; set; } = "";

    public GamePage(ApiClient api, GameClient game)
    {
        InitializeComponent();
        _api = api;
        _game = game;
        BuildBoard();
    }

    // ---------- دورة حياة الصفحة ----------

    protected override void OnAppearing()
    {
        base.OnAppearing();

        if (Mode == "practice")
        {
            if (!_started) StartPractice();
        }
        else
        {
            _game.GameUpdated -= OnGameUpdated;
            _game.GameUpdated += OnGameUpdated;
            _state = _game.Current;
            _receivedAt = DateTime.UtcNow;
            Render();
        }
        _started = true;

        _timer ??= Dispatcher.CreateTimer();
        _timer.Interval = TimeSpan.FromSeconds(1);
        _timer.Tick -= OnTick;
        _timer.Tick += OnTick;
        _timer.Start();
    }

    protected override void OnDisappearing()
    {
        base.OnDisappearing();
        _game.GameUpdated -= OnGameUpdated;
        _timer?.Stop();
        if (Mode != "practice") _game.ClearIfDone();
    }

    private void OnGameUpdated(GameState s)
    {
        MainThread.BeginInvokeOnMainThread(() =>
        {
            if (_state is null || _state.Id == s.Id || _state.IsDone)
            {
                _state = s;
                _receivedAt = DateTime.UtcNow;
                _confirming = false;
                Render();
            }
        });
    }

    // ---------- اللوحة ----------

    private void BuildBoard()
    {
        for (var i = 0; i < 9; i++)
        {
            var b = new Button
            {
                FontSize = 52,
                FontAttributes = FontAttributes.Bold,
                CornerRadius = 12,
                Padding = 0,
                Text = "",
                CommandParameter = i,
            };
            b.Clicked += OnCell;
            _cells[i] = b;
            BoardGrid.Add(b, i % 3, i / 3);
        }
    }

    private static Color Blend(Color a, Color b, double t) => new(
        (float)(a.Red + (b.Red - a.Red) * t),
        (float)(a.Green + (b.Green - a.Green) * t),
        (float)(a.Blue + (b.Blue - a.Blue) * t));

    private void Render()
    {
        BoardGrid.BackgroundColor = Theme.Line;
        var s = _state;

        if (s is null)
        {
            StatusLabel.Text = "لا توجد مباراة جارية.";
            SubLabel.Text = "";
            foreach (var c in _cells) { c.Text = ""; c.BackgroundColor = Theme.Surface; }
            SetButtons(resign: false, confirm: false, claim: false, cancel: false, again: false);
            return;
        }

        var me = _api.PlayerId;
        _myMark = s.XId == me ? "X" : (s.OId == me ? "O" : "");
        var practice = _practice is not null;
        var myTurn = s.IsPlaying && _myMark != "" && s.Turn == _myMark;

        XName.Text = s.XName + (_myMark == "X" ? " (أنت)" : "");
        OName.Text = s.OId is null ? "…" : s.OName + (_myMark == "O" ? " (أنت)" : "");
        XTier.Text = practice ? "" : $"{Rankings.TierOf(s.XRating).Name} · {s.XRating}";
        OTier.Text = practice || s.OId is null ? "" : $"{Rankings.TierOf(s.ORating).Name} · {s.ORating}";
        XCard.BackgroundColor = s.IsPlaying && s.Turn == "X" ? Blend(Theme.Surface, Theme.X, 0.14) : Theme.Surface;
        OCard.BackgroundColor = s.IsPlaying && s.Turn == "O" ? Blend(Theme.Surface, Theme.O, 0.14) : Theme.Surface;

        // الحالة
        if (s.IsWaiting)
        {
            StatusLabel.Text = "بانتظار خصم…";
            SubLabel.Text = "شارك التطبيق مع صديقك أو انتظر أول لاعب ينضم.";
        }
        else if (s.IsPlaying)
        {
            StatusLabel.Text = myTurn ? "دورك" : $"دور {(s.Turn == "X" ? s.XName : s.OName)}";
            SubLabel.Text = "";
        }
        else
        {
            StatusLabel.Text = s.Winner == "D" ? "تعادل"
                : _myMark != "" ? (s.Winner == _myMark ? "فزت" : "خسرت")
                : $"فاز {(s.Winner == "X" ? s.XName : s.OName)}";

            var parts = new List<string>();
            if (s.Reason == "resign") parts.Add("بالاستسلام");
            else if (s.Reason == "timeout") parts.Add("بانسحاب الخصم");
            else if (s.Reason == "abandoned") parts.Add("أُنهيت لعدم النشاط");
            else if (s.Reason == "expired") parts.Add("انتهى وقت الانتظار");
            if (practice) parts.Add("مباراة تدريب");
            else if (_myMark != "")
            {
                var d = _myMark == "X" ? s.XDelta : s.ODelta;
                parts.Add($"{(d > 0 ? "+" : "")}{d} تصنيف");
            }
            SubLabel.Text = string.Join(" · ", parts);
        }

        // الخلايا
        var win = s.Line ?? Array.Empty<int>();
        for (var i = 0; i < 9; i++)
        {
            var m = s.Board[i];
            var btn = _cells[i];
            btn.Text = m == '.' ? "" : m.ToString();
            var markColor = m == 'X' ? Theme.X : Theme.O;
            btn.TextColor = markColor;
            btn.BackgroundColor = win.Contains(i) ? Blend(Theme.Surface, markColor, 0.2) : Theme.Surface;
        }

        // الأزرار
        var playing = s.IsPlaying && _myMark != "";
        SetButtons(
            resign: playing && !_confirming,
            confirm: playing && _confirming,
            claim: false, // يظهر من المؤقت
            cancel: s.IsWaiting && _myMark == "X",
            again: s.IsDone);
        AgainBtn.Text = practice ? "العب مرة ثانية" : "لعب سريع";
        OnTick(null, EventArgs.Empty);
    }

    private void SetButtons(bool resign, bool confirm, bool claim, bool cancel, bool again)
    {
        ResignBtn.IsVisible = resign;
        ConfirmBtn.IsVisible = confirm;
        KeepBtn.IsVisible = confirm;
        ClaimBtn.IsVisible = claim;
        CancelBtn.IsVisible = cancel;
        AgainBtn.IsVisible = again;
    }

    private void OnTick(object? sender, EventArgs e)
    {
        var s = _state;
        if (s is null || !s.IsPlaying || _practice is not null || _myMark == "") return;

        var myTurn = s.Turn == _myMark;
        var elapsed = DateTime.UtcNow - _receivedAt;
        if (myTurn)
        {
            ClaimBtn.IsVisible = false;
            return;
        }
        SubLabel.Text = $"مضى {(int)elapsed.TotalSeconds} ثانية على آخر حركة";
        ClaimBtn.IsVisible = elapsed > ClaimAfter;
    }

    // ---------- الحركات ----------

    private async void OnCell(object? sender, EventArgs e)
    {
        if (_busy || sender is not Button { CommandParameter: int i }) return;
        var s = _state;
        if (s is null || !s.IsPlaying || _myMark == "" || s.Turn != _myMark || s.Board[i] != '.') return;

        if (_practice is not null)
        {
            await PracticeMove(i);
            return;
        }

        _busy = true;
        var r = await _game.MakeMove(s.Id, i);
        _busy = false;
        if (!r.Ok) SubLabel.Text = r.Error ?? "تعذّر إرسال الحركة.";
        else if (r.Game is not null) { _state = r.Game; _receivedAt = DateTime.UtcNow; Render(); }
    }

    private void OnResign(object? sender, EventArgs e) { _confirming = true; Render(); }
    private void OnKeepPlaying(object? sender, EventArgs e) { _confirming = false; Render(); }

    private async void OnConfirmResign(object? sender, EventArgs e)
    {
        _confirming = false;
        if (_practice is not null)
        {
            _practice.Finish('O', "resign");
            SyncPractice();
            return;
        }
        if (_state is null) return;
        var r = await _game.Resign(_state.Id);
        if (!r.Ok) SubLabel.Text = r.Error ?? "";
        else if (r.Game is not null) { _state = r.Game; Render(); }
    }

    private async void OnClaim(object? sender, EventArgs e)
    {
        if (_state is null) return;
        var r = await _game.ClaimTimeout(_state.Id);
        if (!r.Ok) SubLabel.Text = r.Error ?? "";
        else if (r.Game is not null) { _state = r.Game; Render(); }
    }

    private async void OnCancelGame(object? sender, EventArgs e)
    {
        if (_state is null) return;
        var r = await _game.CancelGame(_state.Id);
        if (!r.Ok) { SubLabel.Text = r.Error ?? ""; return; }
        _game.ClearIfDone();
        await Shell.Current.GoToAsync("..");
    }

    private async void OnAgain(object? sender, EventArgs e)
    {
        if (_practice is not null)
        {
            StartPractice();
            return;
        }
        var r = await _game.QuickMatch();
        if (!r.Ok) { SubLabel.Text = r.Error ?? ""; return; }
        _state = r.Game;
        _receivedAt = DateTime.UtcNow;
        _confirming = false;
        Render();
    }

    private async void OnBack(object? sender, EventArgs e) => await Shell.Current.GoToAsync("..");

    // ---------- التدريب ضد الكمبيوتر ----------

    private void StartPractice()
    {
        _practice = new Match { Status = MatchStatus.Playing };
        _confirming = false;
        SyncPractice();
    }

    private void SyncPractice()
    {
        if (_practice is null) return;
        var s = _practice.ToState();
        s.Id = Guid.Empty;
        s.XId = _api.PlayerId;
        s.XName = string.IsNullOrEmpty(_api.Nickname) ? "أنت" : _api.Nickname;
        s.OId = Guid.NewGuid(); // أي معرّف غير معرّفك
        s.OName = "الكمبيوتر";
        _state = s;
        _receivedAt = DateTime.UtcNow;
        Render();
    }

    private async Task PracticeMove(int i)
    {
        if (_practice is null || !_practice.TryMove('X', i, out _)) return;
        SyncPractice();
        if (_practice.Status != MatchStatus.Playing) return;

        _busy = true;
        await Task.Delay(450);
        var m = _practice;
        if (m is not null && m.Status == MatchStatus.Playing)
        {
            var j = Bot.Pick(m.Board, 'O');
            if (j >= 0) m.TryMove('O', j, out _);
            SyncPractice();
        }
        _busy = false;
    }
}
