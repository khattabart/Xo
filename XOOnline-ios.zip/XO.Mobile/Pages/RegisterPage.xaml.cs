using XO.Mobile.Services;

namespace XO.Mobile.Pages;

public partial class RegisterPage : ContentPage
{
    private readonly ApiClient _api;
    private bool _checked;

    public RegisterPage(ApiClient api)
    {
        InitializeComponent();
        _api = api;
        ServerEntry.Text = _api.ServerUrl;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        if (_checked) return;
        _checked = true;

        await _api.LoadAsync();
        if (_api.IsRegistered)
            await Shell.Current.GoToAsync("//main");
    }

    private async void OnStart(object? sender, EventArgs e)
    {
        var nick = (NickEntry.Text ?? "").Trim();
        if (nick.Length < 2)
        {
            ShowError("الاسم يجب أن يكون حرفين على الأقل.");
            return;
        }

        var url = (ServerEntry.Text ?? "").Trim();
        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri) || (uri.Scheme != "http" && uri.Scheme != "https"))
        {
            ShowError("عنوان السيرفر غير صحيح. مثال: http://192.168.1.10:5050");
            return;
        }
        _api.ServerUrl = url;

        StartBtn.IsEnabled = false;
        StatusLabel.IsVisible = false;
        var error = await _api.RegisterAsync(nick);
        StartBtn.IsEnabled = true;

        if (error is not null)
        {
            ShowError(error);
            return;
        }
        await Shell.Current.GoToAsync("//main");
    }

    private void ShowError(string message)
    {
        StatusLabel.Text = message;
        StatusLabel.IsVisible = true;
    }
}
