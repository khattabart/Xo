using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Authentication;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using XO.Server.Data;

namespace XO.Server.Auth;

/// <summary>
/// مصادقة بسيطة: التطبيق يسجّل لاعباً جديداً ويستلم "playerId.token" ويرسله في كل طلب.
/// - طلبات HTTP: الترويسة Authorization: Bearer playerId.token
/// - اتصال SignalR (WebSocket): ?access_token=playerId.token
/// </summary>
public class TokenAuthHandler : AuthenticationHandler<AuthenticationSchemeOptions>
{
    public const string Scheme = "XoToken";
    private readonly XoDbContext _db;

    public TokenAuthHandler(
        IOptionsMonitor<AuthenticationSchemeOptions> options,
        ILoggerFactory logger,
        UrlEncoder encoder,
        XoDbContext db) : base(options, logger, encoder)
    {
        _db = db;
    }

    protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        string? raw = Request.Headers.Authorization.FirstOrDefault();
        if (!string.IsNullOrEmpty(raw) && raw.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
            raw = raw["Bearer ".Length..].Trim();
        else
            raw = Request.Query["access_token"].FirstOrDefault();

        if (string.IsNullOrEmpty(raw))
            return AuthenticateResult.NoResult();

        var dot = raw.IndexOf('.');
        if (dot <= 0 || !Guid.TryParse(raw[..dot], out var id))
            return AuthenticateResult.Fail("رمز غير صالح");

        var token = raw[(dot + 1)..];
        var player = await _db.Players.AsNoTracking().FirstOrDefaultAsync(p => p.Id == id);
        if (player is null || !CryptographicOperations.FixedTimeEquals(
                Encoding.ASCII.GetBytes(Hash(token)), Encoding.ASCII.GetBytes(player.TokenHash)))
            return AuthenticateResult.Fail("رمز غير صالح");

        var identity = new ClaimsIdentity(new[]
        {
            new Claim(ClaimTypes.NameIdentifier, player.Id.ToString()),
            new Claim(ClaimTypes.Name, player.Nickname),
        }, Scheme);

        return AuthenticateResult.Success(
            new AuthenticationTicket(new ClaimsPrincipal(identity), Scheme));
    }

    public static string Hash(string token) =>
        Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(token)));

    public static string NewToken() =>
        Convert.ToBase64String(RandomNumberGenerator.GetBytes(32))
            .Replace('+', '-').Replace('/', '_').TrimEnd('=');
}
