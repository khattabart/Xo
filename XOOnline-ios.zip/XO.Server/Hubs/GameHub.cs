using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using XO.Server.Auth;
using XO.Server.Data;
using XO.Server.Game;
using XO.Shared;

namespace XO.Server.Hubs;

/// <summary>
/// الأحداث من السيرفر إلى التطبيق:
///   GameUpdated(GameState)  - أي تغيير في مباراتك
///   LobbyChanged()          - تغيّرت قائمة المباريات المفتوحة
///   OnlineCount(int)        - عدد المتصلين
/// </summary>
[Authorize(AuthenticationSchemes = TokenAuthHandler.Scheme)]
public class GameHub : Hub
{
    private readonly GameManager _games;
    private readonly XoDbContext _db;

    public GameHub(GameManager games, XoDbContext db)
    {
        _games = games; _db = db;
    }

    private Guid Me => Guid.Parse(Context.UserIdentifier!);

    public override async Task OnConnectedAsync()
    {
        _games.Connected(Me);
        await _games.BroadcastOnlineAsync();
        var active = _games.ActiveStateFor(Me);
        if (active is not null) await Clients.Caller.SendAsync("GameUpdated", active);
        await base.OnConnectedAsync();
    }

    public override async Task OnDisconnectedAsync(Exception? exception)
    {
        _games.Disconnected(Me);
        await _games.BroadcastOnlineAsync();
        await base.OnDisconnectedAsync(exception);
    }

    private async Task<PlayerInfo?> LoadMe()
    {
        var id = Me;
        return await _db.Players.AsNoTracking()
            .Where(p => p.Id == id)
            .Select(p => new PlayerInfo(p.Id, p.Nickname, p.Rating))
            .FirstOrDefaultAsync();
    }

    public int GetOnlineCount() => _games.OnlineCount;

    public Task<List<OpenGame>> GetOpenGames() => Task.FromResult(_games.OpenGames(Me));

    public Task<GameState?> GetActive() => Task.FromResult(_games.ActiveStateFor(Me));

    public async Task<MatchResult> QuickMatch()
    {
        var me = await LoadMe();
        if (me is null) return MatchResult.Fail("اللاعب غير موجود.");
        var op = _games.QuickMatch(me);
        return await AfterStart(op);
    }

    public async Task<MatchResult> CreateGame()
    {
        var me = await LoadMe();
        if (me is null) return MatchResult.Fail("اللاعب غير موجود.");
        return await AfterStart(_games.Create(me));
    }

    public async Task<MatchResult> JoinGame(Guid gameId)
    {
        var me = await LoadMe();
        if (me is null) return MatchResult.Fail("اللاعب غير موجود.");
        return await AfterStart(_games.Join(gameId, me));
    }

    private async Task<MatchResult> AfterStart(Op op)
    {
        if (op.Error is not null) return MatchResult.Fail(op.Error);
        await _games.PushAsync(op.State!);
        await _games.BroadcastLobbyAsync();
        return MatchResult.Success(op.State);
    }

    public async Task<MatchResult> MakeMove(Guid gameId, int index)
    {
        var op = _games.Move(gameId, Me, index);
        return await AfterPlay(op);
    }

    public async Task<MatchResult> Resign(Guid gameId) => await AfterPlay(_games.Resign(gameId, Me));

    public async Task<MatchResult> ClaimTimeout(Guid gameId) => await AfterPlay(_games.ClaimTimeout(gameId, Me));

    public async Task<MatchResult> CancelGame(Guid gameId)
    {
        var op = _games.Cancel(gameId, Me);
        if (op.Error is not null) return MatchResult.Fail(op.Error);
        await _games.PushAsync(op.State!);
        await _games.BroadcastLobbyAsync();
        return MatchResult.Success(op.State);
    }

    private async Task<MatchResult> AfterPlay(Op op)
    {
        if (op.Error is not null) return MatchResult.Fail(op.Error);
        await _games.PushAsync(op.State!);
        if (op.Finished && op.Room is not null) await _games.PersistAsync(op.Room);
        return MatchResult.Success(op.State);
    }
}
