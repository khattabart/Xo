using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using XO.Shared;

namespace XO.Server.Data;

public class PlayerEntity
{
    public Guid Id { get; set; } = Guid.NewGuid();

    [MaxLength(16)]
    public string Nickname { get; set; } = "";

    /// <summary>SHA-256 للرمز السري (لا نحفظ الرمز نفسه).</summary>
    [MaxLength(64)]
    public string TokenHash { get; set; } = "";

    public int Rating { get; set; } = Rankings.StartRating;
    public int Wins { get; set; }
    public int Draws { get; set; }
    public int Losses { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

public class GameRecord
{
    public Guid Id { get; set; }
    public Guid XPlayerId { get; set; }
    public Guid OPlayerId { get; set; }

    [MaxLength(1)]
    public string Winner { get; set; } = "";

    [MaxLength(16)]
    public string Reason { get; set; } = "";

    public int XDelta { get; set; }
    public int ODelta { get; set; }
    public DateTime EndedAt { get; set; } = DateTime.UtcNow;
}

public class XoDbContext : DbContext
{
    public XoDbContext(DbContextOptions<XoDbContext> options) : base(options) { }

    public DbSet<PlayerEntity> Players => Set<PlayerEntity>();
    public DbSet<GameRecord> Games => Set<GameRecord>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<PlayerEntity>().HasIndex(p => p.Rating);
        b.Entity<GameRecord>().HasIndex(g => g.XPlayerId);
        b.Entity<GameRecord>().HasIndex(g => g.OPlayerId);
    }
}
