namespace XO.Server.Game;

/// <summary>خدمة خلفية تنظّف المباريات المهجورة كل 30 ثانية.</summary>
public sealed class GameJanitor : BackgroundService
{
    private readonly GameManager _games;
    private readonly ILogger<GameJanitor> _log;

    public GameJanitor(GameManager games, ILogger<GameJanitor> log)
    {
        _games = games; _log = log;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        using var timer = new PeriodicTimer(TimeSpan.FromSeconds(30));
        while (await timer.WaitForNextTickAsync(stoppingToken))
        {
            try
            {
                var (push, lobby) = _games.Sweep();
                foreach (var s in push) await _games.PushAsync(s);
                if (lobby) await _games.BroadcastLobbyAsync();
            }
            catch (Exception ex)
            {
                _log.LogError(ex, "خطأ أثناء تنظيف المباريات");
            }
        }
    }
}
