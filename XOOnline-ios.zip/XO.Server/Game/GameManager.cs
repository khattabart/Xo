using System.Collections.Concurrent;
using Microsoft.AspNetCore.SignalR;
using XO.Server.Data;
using XO.Server.Hubs;
using XO.Shared;

namespace XO.Server.Game;

public record PlayerInfo(Guid Id, string Name, int Rating);

public sealed class GameRoom
{
    public Guid Id { get; } = Guid.NewGuid();
    public Match M { get; } = new();
    public PlayerInfo X { get; }
    public PlayerInfo? O { get; set; }
    public DateTime CreatedAt { get; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; private set; } = DateTime.UtcNow;
    public DateTime? EndedAt { get; set; }
    public int XDelta { get; set; }
    public int ODelta { get; set; }
    public bool Persisted { get; set; }
    public readonly object Gate = new();

    public GameRoom(PlayerInfo host) => X = host;

    public void Touch() => UpdatedAt = DateTime.UtcNow;

    public char MarkOf(Guid player) =>
        player == X.Id ? 'X' : (O is not null && player == O.Id ? 'O' : '\0');

    public GameState ToState()
    {
        var s = M.ToState();
        s.Id = Id;
        s.XId = X.Id; s.XName = X.Name; s.XRating = X.Rating;
        s.OId = O?.Id; s.OName = O?.Name ?? ""; s.ORating = O?.Rating ?? 0;
        s.XDelta = XDelta; s.ODelta = ODelta;
        s.UpdatedAtUtc = UpdatedAt;
        return s;
    }
}

/// <summary>نتيجة عملية على مباراة. State يُبنى داخل القفل حتى يكون متسقاً.</summary>
public record Op(GameState? State, string? Error, bool Finished, GameRoom? Room)
{
    public static Op Fail(string error) => new(null, error, false, null);
}

/// <summary>
/// يحتفظ بالمباريات الجارية في الذاكرة (السيرفر هو المرجع الوحيد للحركات).
/// ترتيب الأقفال: _matchLock أولاً ثم GameRoom.Gate. لا نأخذ _matchLock أبداً وأنت داخل Gate.
/// </summary>
public sealed class GameManager
{
    public static readonly TimeSpan WaitTtl = TimeSpan.FromMinutes(5);
    public static readonly TimeSpan PlayTtl = TimeSpan.FromMinutes(15);
    public static readonly TimeSpan DoneKeep = TimeSpan.FromMinutes(2);
    public static readonly TimeSpan ClaimAfter = TimeSpan.FromSeconds(45);

    private readonly IHubContext<GameHub> _hub;
    private readonly IServiceScopeFactory _scopes;
    private readonly ILogger<GameManager> _log;

    private readonly ConcurrentDictionary<Guid, GameRoom> _games = new();
    private readonly ConcurrentDictionary<Guid, Guid> _playerGame = new();
    private readonly ConcurrentDictionary<Guid, int> _connections = new();
    private readonly object _matchLock = new();

    public GameManager(IHubContext<GameHub> hub, IServiceScopeFactory scopes, ILogger<GameManager> log)
    {
        _hub = hub; _scopes = scopes; _log = log;
    }

    // ---------- المتصلون ----------

    public int Connected(Guid player)
    {
        _connections.AddOrUpdate(player, 1, (_, n) => n + 1);
        return _connections.Count;
    }

    public int Disconnected(Guid player)
    {
        while (_connections.TryGetValue(player, out var n))
        {
            if (n <= 1) { if (_connections.TryRemove(new KeyValuePair<Guid, int>(player, n))) break; }
            else if (_connections.TryUpdate(player, n - 1, n)) break;
        }
        return _connections.Count;
    }

    public int OnlineCount => _connections.Count;
    public bool IsOnline(Guid player) => _connections.ContainsKey(player);

    // ---------- الاستعلام ----------

    public GameState? ActiveStateFor(Guid player)
    {
        if (_playerGame.TryGetValue(player, out var gid) && _games.TryGetValue(gid, out var g))
            lock (g.Gate) return g.ToState();
        return null;
    }

    public List<OpenGame> OpenGames(Guid except)
    {
        var now = DateTime.UtcNow;
        return _games.Values
            .Where(g => g.M.Status == MatchStatus.Waiting && g.X.Id != except && now - g.CreatedAt < WaitTtl)
            .OrderBy(g => g.CreatedAt)
            .Select(g => new OpenGame { Id = g.Id, HostName = g.X.Name, HostRating = g.X.Rating })
            .ToList();
    }

    // ---------- إنشاء وانضمام ----------

    public Op Create(PlayerInfo p)
    {
        lock (_matchLock)
        {
            if (_playerGame.ContainsKey(p.Id)) return Op.Fail("عندك مباراة جارية بالفعل.");
            var room = new GameRoom(p);
            _games[room.Id] = room;
            _playerGame[p.Id] = room.Id;
            lock (room.Gate) return new Op(room.ToState(), null, false, room);
        }
    }

    public Op Join(Guid gameId, PlayerInfo p)
    {
        lock (_matchLock)
        {
            if (_playerGame.ContainsKey(p.Id)) return Op.Fail("عندك مباراة جارية بالفعل.");
            if (!_games.TryGetValue(gameId, out var room)) return Op.Fail("المباراة غير موجودة.");
            lock (room.Gate)
            {
                if (room.M.Status != MatchStatus.Waiting || room.O is not null) return Op.Fail("سبقك أحد على هذه المباراة.");
                if (room.X.Id == p.Id) return Op.Fail("هذه مباراتك.");
                room.O = p;
                room.M.Status = MatchStatus.Playing;
                room.Touch();
                _playerGame[p.Id] = room.Id;
                return new Op(room.ToState(), null, false, room);
            }
        }
    }

    public Op QuickMatch(PlayerInfo p)
    {
        lock (_matchLock)
        {
            if (_playerGame.TryGetValue(p.Id, out var gid) && _games.TryGetValue(gid, out var cur))
                lock (cur.Gate) return new Op(cur.ToState(), null, false, cur);

            var now = DateTime.UtcNow;
            var candidate = _games.Values
                .Where(g => g.M.Status == MatchStatus.Waiting && g.X.Id != p.Id && now - g.CreatedAt < WaitTtl)
                .OrderBy(g => g.CreatedAt)
                .FirstOrDefault();
            return candidate is null ? Create(p) : Join(candidate.Id, p);
        }
    }

    public Op Cancel(Guid gameId, Guid player)
    {
        GameRoom? room;
        lock (_matchLock)
        {
            if (!_games.TryGetValue(gameId, out room)) return Op.Fail("المباراة غير موجودة.");
            lock (room.Gate)
            {
                if (room.M.Status != MatchStatus.Waiting || room.X.Id != player) return Op.Fail("لا يمكن إلغاء هذه المباراة.");
                room.M.Finish('D', "expired");
                room.Persisted = true; // لا تصنيف لمباراة لم تبدأ
                room.EndedAt = DateTime.UtcNow;
            }
            _games.TryRemove(gameId, out _);
            _playerGame.TryRemove(player, out _);
        }
        lock (room.Gate) return new Op(room.ToState(), null, true, room);
    }

    // ---------- اللعب ----------

    public Op Move(Guid gameId, Guid player, int index)
    {
        if (!_games.TryGetValue(gameId, out var room)) return Op.Fail("المباراة غير موجودة.");
        Op result;
        bool finished;
        lock (room.Gate)
        {
            var mark = room.MarkOf(player);
            if (mark == '\0') return Op.Fail("أنت لست لاعباً في هذه المباراة.");
            if (!room.M.TryMove(mark, index, out var error)) return Op.Fail(error);
            room.Touch();
            finished = room.M.Status == MatchStatus.Done;
            if (finished) FinalizeScores(room);
            result = new Op(room.ToState(), null, finished, room);
        }
        if (finished) Release(room);
        return result;
    }

    public Op Resign(Guid gameId, Guid player)
    {
        if (!_games.TryGetValue(gameId, out var room)) return Op.Fail("المباراة غير موجودة.");
        Op result;
        lock (room.Gate)
        {
            var mark = room.MarkOf(player);
            if (mark == '\0' || room.M.Status != MatchStatus.Playing) return Op.Fail("لا يمكن الاستسلام الآن.");
            room.M.Finish(mark == 'X' ? 'O' : 'X', "resign");
            room.Touch();
            FinalizeScores(room);
            result = new Op(room.ToState(), null, true, room);
        }
        Release(room);
        return result;
    }

    public Op ClaimTimeout(Guid gameId, Guid player)
    {
        if (!_games.TryGetValue(gameId, out var room)) return Op.Fail("المباراة غير موجودة.");
        Op result;
        lock (room.Gate)
        {
            var mark = room.MarkOf(player);
            if (mark == '\0' || room.M.Status != MatchStatus.Playing) return Op.Fail("لا يمكن تنفيذ ذلك الآن.");
            if (room.M.Turn == mark) return Op.Fail("الدور دورك.");
            if (DateTime.UtcNow - room.UpdatedAt < ClaimAfter) return Op.Fail("انتظر قليلاً قبل اعتبار الخصم منسحباً.");
            room.M.Finish(mark, "timeout");
            room.Touch();
            FinalizeScores(room);
            result = new Op(room.ToState(), null, true, room);
        }
        Release(room);
        return result;
    }

    // ---------- النتيجة والحفظ ----------

    /// <summary>يحسب تغيّر التصنيف من التصنيفات وقت بداية المباراة. يُستدعى داخل Gate.</summary>
    private static void FinalizeScores(GameRoom g)
    {
        g.EndedAt = DateTime.UtcNow;
        if (g.O is null) return;
        var xScore = g.M.Winner == 'X' ? 1.0 : g.M.Winner == 'O' ? 0.0 : 0.5;
        g.XDelta = Rankings.Delta(g.X.Rating, g.O.Rating, xScore);
        g.ODelta = Rankings.Delta(g.O.Rating, g.X.Rating, 1.0 - xScore);
    }

    private void Release(GameRoom g)
    {
        lock (_matchLock)
        {
            if (_playerGame.TryGetValue(g.X.Id, out var a) && a == g.Id) _playerGame.TryRemove(g.X.Id, out _);
            if (g.O is not null && _playerGame.TryGetValue(g.O.Id, out var b) && b == g.Id) _playerGame.TryRemove(g.O.Id, out _);
        }
    }

    public async Task PersistAsync(GameRoom g)
    {
        string winner; string reason; int xd, od;
        lock (g.Gate)
        {
            if (g.Persisted || g.O is null) return;
            g.Persisted = true;
            winner = g.M.WinnerString; reason = g.M.Reason; xd = g.XDelta; od = g.ODelta;
        }

        try
        {
            using var scope = _scopes.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<XoDbContext>();
            var ids = new[] { g.X.Id, g.O.Id };
            var players = db.Players.Where(p => ids.Contains(p.Id)).ToDictionary(p => p.Id);

            void Apply(Guid id, int delta, bool won, bool draw)
            {
                if (!players.TryGetValue(id, out var p)) return;
                p.Rating = Math.Max(Rankings.MinRating, p.Rating + delta);
                if (draw) p.Draws++; else if (won) p.Wins++; else p.Losses++;
            }

            var draw = winner == "D";
            Apply(g.X.Id, xd, winner == "X", draw);
            Apply(g.O.Id, od, winner == "O", draw);

            db.Games.Add(new GameRecord
            {
                Id = g.Id, XPlayerId = g.X.Id, OPlayerId = g.O.Id,
                Winner = winner, Reason = reason, XDelta = xd, ODelta = od, EndedAt = DateTime.UtcNow,
            });
            await db.SaveChangesAsync();
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "فشل حفظ نتيجة المباراة {Id}", g.Id);
        }
    }

    // ---------- الإرسال ----------

    public Task PushAsync(GameState s)
    {
        var users = new List<string> { s.XId.ToString() };
        if (s.OId is { } o) users.Add(o.ToString());
        return _hub.Clients.Users(users).SendAsync("GameUpdated", s);
    }

    public Task BroadcastLobbyAsync() => _hub.Clients.All.SendAsync("LobbyChanged");
    public Task BroadcastOnlineAsync() => _hub.Clients.All.SendAsync("OnlineCount", OnlineCount);

    // ---------- التنظيف الدوري ----------

    /// <summary>ينهي المباريات المنتهية صلاحيتها ويحذف القديمة. يرجع الحالات التي يجب إرسالها.</summary>
    public (List<GameState> ToPush, bool LobbyChanged) Sweep()
    {
        var now = DateTime.UtcNow;
        var push = new List<GameState>();
        var lobby = false;

        foreach (var room in _games.Values.ToList())
        {
            GameState? state = null;
            var remove = false;
            var release = false;

            lock (room.Gate)
            {
                switch (room.M.Status)
                {
                    case MatchStatus.Waiting when now - room.CreatedAt > WaitTtl:
                        room.M.Finish('D', "expired");
                        room.Persisted = true; room.EndedAt = now;
                        state = room.ToState(); remove = true; release = true; lobby = true;
                        break;
                    case MatchStatus.Playing when now - room.UpdatedAt > PlayTtl:
                        room.M.Finish('D', "abandoned");
                        room.Persisted = true; room.EndedAt = now; // بدون تغيير تصنيف
                        state = room.ToState(); release = true;
                        break;
                    case MatchStatus.Done when room.EndedAt is { } e && now - e > DoneKeep:
                        remove = true;
                        break;
                }
            }

            if (release) Release(room);
            if (remove) _games.TryRemove(room.Id, out _);
            if (state is not null) push.Add(state);
        }
        return (push, lobby);
    }
}
