using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.EntityFrameworkCore;
using XO.Server.Auth;
using XO.Server.Data;
using XO.Server.Game;
using XO.Server.Hubs;
using XO.Shared;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<XoDbContext>(o =>
    o.UseSqlServer(builder.Configuration.GetConnectionString("Default")));

builder.Services
    .AddAuthentication(TokenAuthHandler.Scheme)
    .AddScheme<AuthenticationSchemeOptions, TokenAuthHandler>(TokenAuthHandler.Scheme, null);
builder.Services.AddAuthorization();

builder.Services.AddSignalR();
builder.Services.AddSingleton<GameManager>();
builder.Services.AddHostedService<GameJanitor>();

var app = builder.Build();

// ينشئ قاعدة البيانات والجداول عند أول تشغيل
using (var scope = app.Services.CreateScope())
{
    scope.ServiceProvider.GetRequiredService<XoDbContext>().Database.EnsureCreated();
}

app.UseAuthentication();
app.UseAuthorization();

app.MapGet("/", () => "XO server is running.");

// ---------- تسجيل لاعب جديد ----------
app.MapPost("/api/register", async (RegisterRequest req, XoDbContext db) =>
{
    var nick = (req.Nickname ?? "").Trim();
    if (nick.Length < 2 || nick.Length > 16)
        return Results.BadRequest(new ErrorResponse { Error = "الاسم يجب أن يكون بين حرفين و16 حرفاً." });

    var token = TokenAuthHandler.NewToken();
    var player = new PlayerEntity { Nickname = nick, TokenHash = TokenAuthHandler.Hash(token) };
    db.Players.Add(player);
    await db.SaveChangesAsync();

    return Results.Ok(new RegisterResponse { PlayerId = player.Id, Token = token, Nickname = player.Nickname });
});

// ---------- ملفي ----------
app.MapGet("/api/me", async (ClaimsPrincipal user, XoDbContext db) =>
{
    var id = Guid.Parse(user.FindFirstValue(ClaimTypes.NameIdentifier)!);
    var p = await db.Players.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
    return p is null
        ? Results.NotFound()
        : Results.Ok(new PlayerProfile
        {
            Id = p.Id, Nickname = p.Nickname, Rating = p.Rating,
            Wins = p.Wins, Draws = p.Draws, Losses = p.Losses,
        });
}).RequireAuthorization();

app.MapPut("/api/me/nickname", async (RenameRequest req, ClaimsPrincipal user, XoDbContext db) =>
{
    var nick = (req.Nickname ?? "").Trim();
    if (nick.Length < 2 || nick.Length > 16)
        return Results.BadRequest(new ErrorResponse { Error = "الاسم يجب أن يكون بين حرفين و16 حرفاً." });

    var id = Guid.Parse(user.FindFirstValue(ClaimTypes.NameIdentifier)!);
    var p = await db.Players.FirstOrDefaultAsync(x => x.Id == id);
    if (p is null) return Results.NotFound();
    p.Nickname = nick;
    await db.SaveChangesAsync();
    return Results.Ok(new { nickname = nick });
}).RequireAuthorization();

// ---------- لوحة الترتيب ----------
app.MapGet("/api/leaderboard", async (int? take, XoDbContext db, GameManager games) =>
{
    var n = Math.Clamp(take ?? 50, 1, 100);
    var rows = await db.Players.AsNoTracking()
        .OrderByDescending(p => p.Rating).ThenByDescending(p => p.Wins).ThenBy(p => p.CreatedAt)
        .Take(n)
        .Select(p => new { p.Id, p.Nickname, p.Rating, p.Wins, p.Draws, p.Losses })
        .ToListAsync();

    var list = rows.Select((p, i) => new LeaderboardEntry
    {
        Rank = i + 1, PlayerId = p.Id, Nickname = p.Nickname, Rating = p.Rating,
        Wins = p.Wins, Draws = p.Draws, Losses = p.Losses, Online = games.IsOnline(p.Id),
    }).ToList();
    return Results.Ok(list);
});

app.MapHub<GameHub>("/hub");

app.Run();
