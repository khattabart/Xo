namespace XO.Shared;

/// <summary>خصم الكمبيوتر للتدريب: minimax كامل، مع 25% حركات عشوائية حتى يمكن الفوز عليه.</summary>
public static class Bot
{
    private static readonly Random Rng = new();

    public static int Pick(char[] board, char bot = 'O')
    {
        var empty = Enumerable.Range(0, 9).Where(i => board[i] == '.').ToList();
        if (empty.Count == 0) return -1;
        if (Rng.NextDouble() < 0.25) return empty[Rng.Next(empty.Count)];

        var best = int.MinValue;
        var picks = new List<int>();
        var work = (char[])board.Clone();
        foreach (var i in empty)
        {
            work[i] = bot;
            var v = Minimax(work, bot == 'X' ? 'O' : 'X', bot);
            work[i] = '.';
            if (v > best) { best = v; picks.Clear(); picks.Add(i); }
            else if (v == best) picks.Add(i);
        }
        return picks[Rng.Next(picks.Count)];
    }

    private static int Minimax(char[] b, char turn, char bot)
    {
        if (Match.Evaluate(b) is { } r)
            return r.Winner == 'D' ? 0 : (r.Winner == bot ? 1 : -1);

        var maximizing = turn == bot;
        var best = maximizing ? int.MinValue : int.MaxValue;
        for (var i = 0; i < 9; i++)
        {
            if (b[i] != '.') continue;
            b[i] = turn;
            var v = Minimax(b, turn == 'X' ? 'O' : 'X', bot);
            b[i] = '.';
            best = maximizing ? Math.Max(best, v) : Math.Min(best, v);
        }
        return best;
    }
}
