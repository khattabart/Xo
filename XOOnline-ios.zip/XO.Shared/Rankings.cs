namespace XO.Shared;

public readonly record struct Tier(int Min, string Name, string Color);

/// <summary>التصنيف (Elo) والرتب والمستويات.</summary>
public static class Rankings
{
    public const int StartRating = 800;
    public const int MinRating = 100;
    private const int K = 32;

    public static readonly Tier[] Tiers =
    {
        new(0, "برونز", "#B9803F"),
        new(900, "فضة", "#8E9CA6"),
        new(1000, "ذهب", "#D4A017"),
        new(1100, "بلاتين", "#2FA79F"),
        new(1200, "ماس", "#4C8DFF"),
        new(1300, "أسطورة", "#E0502F"),
    };

    public static Tier TierOf(int rating)
    {
        var t = Tiers[0];
        foreach (var x in Tiers)
            if (rating >= x.Min) t = x;
        return t;
    }

    /// <summary>التغيير في التصنيف. score: 1 فوز، 0.5 تعادل، 0 خسارة.</summary>
    public static int Delta(int own, int opponent, double score)
    {
        var expected = 1.0 / (1.0 + Math.Pow(10, (opponent - own) / 400.0));
        return (int)Math.Round(K * (score - expected), MidpointRounding.AwayFromZero);
    }

    // نقاط الخبرة: فوز 20، تعادل 10، خسارة 5
    public static int Xp(int wins, int draws, int losses) => wins * 20 + draws * 10 + losses * 5;
    public static int Level(int xp) => (int)Math.Floor(Math.Sqrt(xp / 20.0)) + 1;
    public static (int Lo, int Hi) LevelRange(int level) => (20 * (level - 1) * (level - 1), 20 * level * level);
}
