namespace XO.Shared;

public enum MatchStatus { Waiting, Playing, Done }

/// <summary>
/// قواعد لعبة XO. يستخدمها السيرفر (المباريات الأونلاين) والتطبيق (التدريب ضد الكمبيوتر).
/// الرموز: 'X' و 'O'، والخانة الفارغة '.'، والفائز 'X' أو 'O' أو 'D' للتعادل.
/// </summary>
public sealed class Match
{
    public static readonly int[][] Lines =
    {
        new[] { 0, 1, 2 }, new[] { 3, 4, 5 }, new[] { 6, 7, 8 },
        new[] { 0, 3, 6 }, new[] { 1, 4, 7 }, new[] { 2, 5, 8 },
        new[] { 0, 4, 8 }, new[] { 2, 4, 6 },
    };

    public char[] Board { get; } = new string('.', 9).ToCharArray();
    public char Turn { get; private set; } = 'X';
    public MatchStatus Status { get; set; } = MatchStatus.Waiting;
    public char Winner { get; private set; } = '\0';
    public int[]? Line { get; private set; }
    public int Last { get; private set; } = -1;
    public int Moves { get; private set; }
    public string Reason { get; set; } = "";

    public string BoardString => new string(Board);
    public string WinnerString => Winner == '\0' ? "" : Winner.ToString();

    /// <summary>يرجع الفائز (أو 'D' للتعادل) والخط الفائز، أو null إذا المباراة مستمرة.</summary>
    public static (char Winner, int[]? Line)? Evaluate(char[] board)
    {
        foreach (var l in Lines)
        {
            var c = board[l[0]];
            if (c != '.' && c == board[l[1]] && c == board[l[2]])
                return (c, l);
        }
        if (board.All(c => c != '.')) return ('D', (int[]?)null);
        return null;
    }

    public bool TryMove(char mark, int index, out string error)
    {
        error = "";
        if (Status != MatchStatus.Playing) { error = "المباراة غير جارية."; return false; }
        if (mark != Turn) { error = "ليس دورك."; return false; }
        if (index < 0 || index > 8) { error = "خانة غير صحيحة."; return false; }
        if (Board[index] != '.') { error = "الخانة مأخوذة."; return false; }

        Board[index] = mark;
        Last = index;
        Moves++;

        var result = Evaluate(Board);
        if (result is { } r)
            Finish(r.Winner, "", r.Line);
        else
            Turn = mark == 'X' ? 'O' : 'X';
        return true;
    }

    public void Finish(char winner, string reason, int[]? line = null)
    {
        Status = MatchStatus.Done;
        Winner = winner;
        Reason = reason;
        Line = line;
    }
}
