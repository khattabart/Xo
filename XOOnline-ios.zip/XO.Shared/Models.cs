namespace XO.Shared;

// ---------- طلبات واستجابات HTTP ----------

public class RegisterRequest { public string Nickname { get; set; } = ""; }

public class RegisterResponse
{
    public Guid PlayerId { get; set; }
    public string Token { get; set; } = "";
    public string Nickname { get; set; } = "";
}

public class RenameRequest { public string Nickname { get; set; } = ""; }

public class ErrorResponse { public string Error { get; set; } = ""; }

// ---------- اللاعبون ----------

public class PlayerProfile
{
    public Guid Id { get; set; }
    public string Nickname { get; set; } = "";
    public int Rating { get; set; } = Rankings.StartRating;
    public int Wins { get; set; }
    public int Draws { get; set; }
    public int Losses { get; set; }

    public int Games => Wins + Draws + Losses;
    public int Xp => Rankings.Xp(Wins, Draws, Losses);
    public int Level => Rankings.Level(Xp);
}

public class LeaderboardEntry
{
    public int Rank { get; set; }
    public Guid PlayerId { get; set; }
    public string Nickname { get; set; } = "";
    public int Rating { get; set; }
    public int Wins { get; set; }
    public int Draws { get; set; }
    public int Losses { get; set; }
    public bool Online { get; set; }

    public int Level => Rankings.Level(Rankings.Xp(Wins, Draws, Losses));
}

// ---------- المباريات (SignalR) ----------

public class OpenGame
{
    public Guid Id { get; set; }
    public string HostName { get; set; } = "";
    public int HostRating { get; set; }
}

public class GameState
{
    public Guid Id { get; set; }
    /// <summary>تسعة رموز: X أو O أو نقطة للخانة الفارغة.</summary>
    public string Board { get; set; } = ".........";
    public string Turn { get; set; } = "X";
    /// <summary>Waiting أو Playing أو Done</summary>
    public string Status { get; set; } = "Waiting";
    /// <summary>"" أو X أو O أو D (تعادل)</summary>
    public string Winner { get; set; } = "";
    public int[]? Line { get; set; }
    public int Last { get; set; } = -1;
    public int Moves { get; set; }
    /// <summary>"" أو resign أو timeout أو abandoned أو expired</summary>
    public string Reason { get; set; } = "";

    public Guid XId { get; set; }
    public string XName { get; set; } = "";
    public int XRating { get; set; }
    public Guid? OId { get; set; }
    public string OName { get; set; } = "";
    public int ORating { get; set; }

    public int XDelta { get; set; }
    public int ODelta { get; set; }
    public DateTime UpdatedAtUtc { get; set; } = DateTime.UtcNow;

    public bool IsDone => Status == "Done";
    public bool IsPlaying => Status == "Playing";
    public bool IsWaiting => Status == "Waiting";
}

public class MatchResult
{
    public bool Ok { get; set; }
    public string? Error { get; set; }
    public GameState? Game { get; set; }

    public static MatchResult Success(GameState? g) => new() { Ok = true, Game = g };
    public static MatchResult Fail(string error) => new() { Ok = false, Error = error };
}

public static class MatchExtensions
{
    /// <summary>يحوّل حالة اللعبة إلى DTO (بدون بيانات اللاعبين).</summary>
    public static GameState ToState(this Match m) => new()
    {
        Board = m.BoardString,
        Turn = m.Turn.ToString(),
        Status = m.Status.ToString(),
        Winner = m.WinnerString,
        Line = m.Line,
        Last = m.Last,
        Moves = m.Moves,
        Reason = m.Reason,
        UpdatedAtUtc = DateTime.UtcNow,
    };
}
